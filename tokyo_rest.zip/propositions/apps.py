from django.apps import AppConfig


class PropositionsConfig(AppConfig):
    name = 'propositions'
